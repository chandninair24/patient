package com.capgemini.tccsa.DAO;
import java.util.List;

import com.capgemini.tccsa.bean.*;

import com.capgemini.tccsa.exception.PatientsException;
public interface IPatientDAO {
	public String addPatientDetails(PatientBean patientbean) throws PatientsException;

	public List<PatientBean> retriveAllDetails()throws PatientsException;
}





