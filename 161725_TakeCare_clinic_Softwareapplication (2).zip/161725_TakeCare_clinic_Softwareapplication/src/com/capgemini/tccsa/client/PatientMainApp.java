package com.capgemini.tccsa.client;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.tccsa.bean.*;
import com.capgemini.tccsa.exception.*;
import com.capgemini.tccsa.service.*;
import com.capgemini.tccsa.DAO.*;
import com.capgemini.tccsa.DAO.PatientDAOImpl;
import com.capgemini.tccsa.bean.PatientBean;


import java.lang.NullPointerException;

@SuppressWarnings("unused")
public class PatientMainApp
{
//setting up references
	static Scanner sc = new Scanner(System.in);
	static IPatientService patientService = null;
	static PatientServiceImpl patientServiceImpl = null;
	static Logger logger = Logger.getRootLogger();

	public static void main(String[] args) throws Exception {
		//configuring logger properties
		PropertyConfigurator.configure("resourses//log4j.properties");
		PatientBean patientbean = null;

		String patient_id = null;
		int option = 0;

		

			// showing menu
			
			
			System.out.println("Patient Information");
			
			System.out.println("1.Add Patient Information");
			System.out.println("2.Search Patient by Id");
			System.out.println("3.Exit");
			System.out.println("Enter Your Choice:");
			// accept option

			try {
				option = sc.nextInt();

				switch (option) {

				case 1:
					//to add patient details

					while (patientbean  == null) {
						patientbean   = populatePatientbean ();
						 System.out.println(patientbean);
					}

					try {
						patientService = new PatientServiceImpl();
						patient_id = patientService.addPatientDetails(patientbean);

						System.out.print("Patient Information stored successfully for");
						System.out.println(patient_id);

					} catch (com.capgemini.tccsa.exception.PatientsException patientsException) {
						logger.error("exception occured", patientsException);
						System.out.println("ERROR : "
								+ patientsException.getMessage());
					} finally {
						patient_id = null;
						patientService = null;
						patientbean = null;
					}

					break;
					
				case 2:
					//for retriving patient information

					patientService = new PatientServiceImpl();
					try {
						List<PatientBean> patientList = new ArrayList<PatientBean>();
						patientList = patientService.retriveAll();

						if (patientList != null) {
							Iterator<PatientBean> i = patientList.iterator();
							while (i.hasNext()) {
								System.out.println(i.next());
							}
						} else {
							System.out
									.println("There is no patient with this ID");
						}

					}

					catch (PatientsException e) {

						System.out.println("Error  :" + e.getMessage());
					}

					break;


				case 3:
// exit the menu
					System.out.print("Exit Patient Application");
					System.exit(0);
					break;
				default:
					System.out.println("Enter a valid option[1-4]");
				}// end of switch
			}

			catch (InputMismatchException e) {
				sc.nextLine();
				System.err.println("Please enter a numeric value, try again");
		}

		}
	

	private static PatientBean populatePatientbean() throws Exception {

		
		PatientBean patientbean = new PatientBean();

		System.out.println("\n Patient Information");

		System.out.println("Enter the name of the Patient: ");
		patientbean.setName(sc.next());
		System.out.println("Enter Patient Age: ");
		patientbean.setAge(sc.next());
		System.out.println("Enter Patient phone number: ");
		patientbean.setPhoneNumber(sc.next());
		System.out.println("Enter Description: ");
		patientbean.setDescription(sc.next());
		
	
		
        patientServiceImpl = new PatientServiceImpl();
;

		try {
			patientServiceImpl.validatePatient(patientbean);
			
			System.out.println("after validate patient");
			return patientbean ;
		} catch (PatientsException patientsException) {
			logger.error("exception occured", patientsException);
			System.err.println("Invalid data:");
			System.err.println(patientsException.getMessage() + " \n Try again..");
			System.exit(0);

		}
		return null;

	}
}
