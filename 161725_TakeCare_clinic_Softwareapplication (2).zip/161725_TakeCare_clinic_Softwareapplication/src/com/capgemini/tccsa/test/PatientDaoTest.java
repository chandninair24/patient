package com.capgemini.tccsa.test;  

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.capgemini.tccsa.bean.*;
import com.capgemini.tccsa.DAO.*;
import com.capgemini.tccsa.exception.*;


public class PatientDaoTest {

    static PatientDAOImpl dao;
    static PatientBean patientbean;

    @BeforeClass
    public static void initialize() {
        dao = new PatientDAOImpl();
        patientbean = new PatientBean();
    }

    @Test
    public void testAddPatientDetails() throws PatientsException {

        assertNotNull(dao.addPatientDetails(patientbean));
    }
    
    /************************************
     * Test case for addPatientDetails()
     * 
     ************************************/

    @Ignore
    @Test
    public void testAddPatientDetails1() throws PatientsException {
        assertEquals(1001, dao.addPatientDetails(patientbean));
    }

    /************************************
     * Test case for addPatientDetails()
     * 
     ************************************/

    @Test
    public void testAddPatientDetails2() throws PatientsException {
        
    	patientbean.setName("sai");
    	patientbean.setPhoneNumber("8056342399");
    	patientbean.setAge("35");
    	patientbean.setDescription("fever");
        assertTrue("Data Inserted successfully",
                Integer.parseInt(dao.addPatientDetails(patientbean)) > 1000);

    }
}