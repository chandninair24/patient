package com.capgemini.tccsa.exception;

public class PatientsException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public PatientsException(String message) 
	{
		
		super(message);
	}

}
