package com.capgemini.tccsa.service;

import java.util.List;


import com.capgemini.tccsa.bean.*;
import com.capgemini.tccsa.exception.*;


public interface IPatientService {
	public String addPatientDetails(PatientBean patientbean) throws PatientsException;
	public List<PatientBean> retriveAll()throws PatientsException;
}
